package com.wadaro.erp.model.table;

import java.util.Date;

/**
 * Created by pho0890910 on 2/26/2019.
 */
public class ArealPenugasanData {

    public int id;
    public Date tanggal;
    public String kecamatan;
    public String kelurahan;

}
