package com.wadaro.erp.ui.secure.demobooker.laporanhasilbooking.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.wadaro.erp.R;
import com.wadaro.erp.model.table.DemoData;
import com.wadaro.erp.model.table.LaporanHasilBookingData;
import com.wadaro.erp.ui.secure.demobooker.DataBookingDetilActivity;
import com.wadaro.erp.ui.secure.demobooker.LaporanHasilBookingDetilActivity;

import java.text.SimpleDateFormat;


public class LaporanTabelFragment extends Fragment {

    private TableLayout mTableLayout;
//    ProgressDialog mProgressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_laporan_tabel, container, false);

        mTableLayout = v.findViewById(R.id.tableDemo);

        mTableLayout.setStretchAllColumns(true);
        mTableLayout.setColumnShrinkable(0,true);
        mTableLayout.setColumnShrinkable(2,true);
        mTableLayout.setColumnShrinkable(3,true);
        mTableLayout.setColumnShrinkable(4,true);

        loadData();

        return v;
    }


    public void loadData() {

        int leftRowMargin=0;
        int topRowMargin=0;
        int rightRowMargin=0;
        int bottomRowMargin = 0;
        int textSize = 0, smallTextSize =0, mediumTextSize = 0;

        textSize = (int) getResources().getDimension(R.dimen.font_size_verysmall);
        smallTextSize = (int) getResources().getDimension(R.dimen.font_size_small);
        mediumTextSize = (int) getResources().getDimension(R.dimen.font_size_medium);

        LaporanHasilBookingData[] data = getLaporanHasilBookingData();

        int rows = data.length;
        TextView textSpacer = null;

        mTableLayout.removeAllViews();

        // -1 means heading row
        for(int i = -1; i < rows; i ++) {
            LaporanHasilBookingData row = null;
            if (i > -1)
                row = data[i];
            else {
                textSpacer = new TextView(getActivity());
                textSpacer.setText("");

            }
            // data columns
            final TextView tv = new TextView(getActivity());
            tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.MATCH_PARENT));

            tv.setPadding(5, 15, 0, 15);
            if (i == -1) {
                tv.setText("Demo");
                tv.setBackgroundColor(Color.parseColor("#f0f0f0"));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv.setBackgroundColor(Color.parseColor("#f8f8f8"));
                tv.setText(R.string.test_demo);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv.setGravity(Gravity.LEFT);
                tv.setTextColor(getResources().getColor(R.color.lupa_pass_color));

                tv.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        //do whatever action is needed
                        startActivity(new Intent(getActivity(), LaporanHasilBookingDetilActivity.class));
                    }
                });

            }

            final TextView tv2 = new TextView(getActivity());
            tv2.setPadding(5, 15, 0, 15);
            if (i == -1) {
                tv2.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv2.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv2.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv2.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv2.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv2.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv2.setText("Jam");
                tv2.setBackgroundColor(Color.parseColor("#f7f7f7"));
            }else {
                tv2.setBackgroundColor(Color.parseColor("#ffffff"));
                tv2.setTextColor(Color.parseColor("#000000"));
                tv2.setText(" "+row.jam);
            }

            final TextView tv3 = new TextView(getActivity());
            tv3.setPadding(5, 15, 0, 15);

            if (i == -1) {
                tv3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv3.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv3.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv3.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv3.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv3.setText("Kordinator");
                tv3.setBackgroundColor(Color.parseColor("#f0f0f0"));
            } else {
                tv3.setBackgroundColor(Color.parseColor("#f8f8f8"));
                tv3.setTextColor(Color.parseColor("#000000"));
                tv3.setText(" "+row.kordinator);
            }

            final TextView tv4 = new TextView(getActivity());
            tv4.setPadding(5, 15, 0, 15);
            if (i == -1) {
                tv4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv4.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv4.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv4.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv4.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv4.setText("Sales");
                tv4.setBackgroundColor(Color.parseColor("#f7f7f7"));
            }else {
                tv4.setBackgroundColor(Color.parseColor("#ffffff"));
                tv4.setTextColor(Color.parseColor("#000000"));
                tv4.setText(" "+row.sales);
            }

            final TextView tv5 = new TextView(getActivity());
            tv3.setPadding(5, 15, 0, 15);

            if (i == -1) {
                tv5.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv5.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv5.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv5.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv5.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv5.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv5.setText("Status");
                tv5.setBackgroundColor(Color.parseColor("#f0f0f0"));
            } else {
                tv5.setBackgroundColor(Color.parseColor("#f8f8f8"));
                tv5.setTextColor(Color.parseColor("#000000"));
                tv5.setText(" "+row.status);
            }

            // add table row
            final TableRow tr = new TableRow(getActivity());
            tr.setId(i + 1);
            TableLayout.LayoutParams trParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT);
            trParams.setMargins(leftRowMargin, topRowMargin, rightRowMargin, bottomRowMargin);
            tr.setPadding(0,0,0,0);
            tr.setLayoutParams(trParams);

            tr.addView(tv);
            tr.addView(tv2);
            tr.addView(tv3);
            tr.addView(tv4);
            tr.addView(tv5);

            mTableLayout.addView(tr, trParams);

            if (i > -1) {

                // add separator row
                final TableRow trSep = new TableRow(getActivity());
                TableLayout.LayoutParams trParamsSep = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                        TableLayout.LayoutParams.WRAP_CONTENT);
                trParamsSep.setMargins(leftRowMargin, topRowMargin, rightRowMargin, bottomRowMargin);

                trSep.setLayoutParams(trParamsSep);
                TextView tvSep = new TextView(getActivity());
                TableRow.LayoutParams tvSepLay = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT);
                tvSepLay.span = 5;
                tvSep.setLayoutParams(tvSepLay);
                tvSep.setBackgroundColor(Color.parseColor("#d9d9d9"));
                tvSep.setHeight(1);

                trSep.addView(tvSep);
                mTableLayout.addView(trSep, trParamsSep);
            }

        }
    }

    public LaporanHasilBookingData[] getLaporanHasilBookingData() {
        LaporanHasilBookingData[] data = new LaporanHasilBookingData[4];
        for(int i = 0; i < 4; i ++) {
            LaporanHasilBookingData row = new LaporanHasilBookingData();
            row.id = (i+1);
            row.demo = "Demo 1";
            row.jam =  "10:00";
            row.kordinator = "Dewi";
            row.sales = "Budi";
            row.status = "Sales Order";
            data[i] = row;
        }
        return data;
    }

}
