package com.wadaro.erp.ui.secure.demobooker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.wadaro.erp.R;
import com.wadaro.erp.ui.secure.SecureBaseUi;

import java.util.ArrayList;

public class PenugasanSPActivity extends SecureBaseUi {

    @Override
    protected int getContentViewId() {
        return R.layout.activity_penugasan_sp;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_penugasan;
    }

    @Override
    protected void onMyCreate() {

        ArrayList<String> temp = new ArrayList<>();
        temp.add("2019-01-10");
        temp.add("2019-01-11");

        Spinner spinner = (Spinner) findViewById(R.id.spTanggalDemo);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        ArrayList<String> temp2 = new ArrayList<>();
        temp2.add("Demo 1");
        temp2.add("Demo 2");

        Spinner spinner2 = (Spinner) findViewById(R.id.spJadwalDemo);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp2);

        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        ArrayList<String> temp3 = new ArrayList<>();
        temp3.add("Semua");

        Spinner spinner3 = (Spinner) findViewById(R.id.spSalesPromotor);

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp3);

        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter3);

        ArrayList<String> temp4 = new ArrayList<>();
        temp4.add("Budi");
        temp4.add("Alan");

        Spinner spinner4 = (Spinner) findViewById(R.id.spTest1);

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, R.layout.simple_spinner, temp4);

        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter4);

        ArrayList<String> temp5 = new ArrayList<>();
        temp5.add("Budi");
        temp5.add("Alan");

        Spinner spinner5 = (Spinner) findViewById(R.id.spTest2);

        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this, R.layout.simple_spinner, temp5);

        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);

    }

}
