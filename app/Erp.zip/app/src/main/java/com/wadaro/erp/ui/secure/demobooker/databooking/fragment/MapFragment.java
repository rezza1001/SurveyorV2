package com.wadaro.erp.ui.secure.demobooker.databooking.fragment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.ui.IconGenerator;
import com.wadaro.erp.R;


public class MapFragment extends Fragment implements GoogleMap.OnMarkerClickListener { // implements OnMapReadyCallback {

    private MapView mMapView;
    private GoogleMap mGoogleMap;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_map, container, false);

        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(getActivity(), "Membutuhkan Izin Lokasi", Toast.LENGTH_SHORT).show();
            } else {

                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                        1);
            }
        } else {
            // Permission has already been granted
//            Toast.makeText(getActivity(), "Izin Lokasi diberikan", Toast.LENGTH_SHORT).show();

            setUpMapIfNeeded(v);
        }

        // Inflate the layout for this fragment
        return v;
    }

    private void setUpMapIfNeeded(View v) {

        if (mGoogleMap == null) {
            mMapView = (MapView) v.findViewById(R.id.mvMap);
            mMapView.onCreate(getArguments());
            mMapView.onResume();

            try {
                MapsInitializer.initialize(getActivity());
                final GoogleMap.OnMarkerClickListener markerClickListener = this;
                mMapView.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(GoogleMap gmap) {
                        mGoogleMap = gmap;
                        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

                        //fill markers
                        //add marker listener

                        // latitude and longitude
                        double latitude = -6.284310;
                        double longitude = 106.727430;
//                        // create marker
//                        MarkerOptions marker = new MarkerOptions().position(
//                                new LatLng(latitude, longitude)).title("Demo 1");
//
//                        // Changing marker icon
//                        marker.icon(BitmapDescriptorFactory
//                                .defaultMarker(BitmapDescriptorFactory.HUE_ROSE));
//
//                        double latitude2 = -6.270750;
//                        double longitude2 = 106.687140;
//
//                        MarkerOptions marker2 = new MarkerOptions().position(
//                                new LatLng(latitude2, longitude2)).title("Demo 2");
//
//                        // Changing marker icon
//                        marker2.icon(BitmapDescriptorFactory
//                                .defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
//
//                        // adding marker
//                        mGoogleMap.addMarker(marker).showInfoWindow();
//                        mGoogleMap.addMarker(marker2);

                        makersMaker(mGoogleMap);

                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(new LatLng(latitude, longitude)).zoom(10).build();
                        mGoogleMap.animateCamera(CameraUpdateFactory
                                .newCameraPosition(cameraPosition));


//                        mGoogleMap.addMarker(new
//                                MarkerOptions().position(latLng).title("Demo 1"));
//
//                        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        return false;
    }

    public void makersMaker(GoogleMap googleMap){
        double latitude = -6.284310;
        double longitude = 106.727430;
        double latitude2 = -6.300750;
        double longitude2 = 106.587140;

        IconGenerator iconGenerator = new IconGenerator(getActivity());
        Marker marker1 = googleMap.addMarker(new MarkerOptions().position(
                new LatLng(latitude, longitude)));
        marker1.setIcon(BitmapDescriptorFactory.fromBitmap(iconGenerator.makeIcon("Demo 1")));
        Marker marker2 = googleMap.addMarker(new MarkerOptions().position(
                new LatLng(latitude2, longitude2)));
        marker2.setIcon(BitmapDescriptorFactory.fromBitmap(iconGenerator.makeIcon("Demo 2")));

    }


    //todo
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        switch (requestCode) {
//            case 1:
//                if (grantResults.length > 0 && grantResults[0] ==
//                        PackageManager.PERMISSION_GRANTED) {
//                    if (checkPlaySercives()) {
//                        buildGoogleApiClient();
//                        creatLocationRequest();
//                        displayLocation();
//                    }
//                }
//                break;
//        }
//    }

}
