package com.wadaro.erp.ui.secure;

import android.content.Intent;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.wadaro.erp.R;
import com.wadaro.erp.adapter.HomeMenuGridViewAdapter;
import com.wadaro.erp.adapter.HomeNewsListViewAdapter;
import com.wadaro.erp.model.ItemObject;
import com.wadaro.erp.ui.secure.demobooker.DataArealGarapanActivity;
import com.wadaro.erp.ui.secure.demobooker.DataBookingActivity;
import com.wadaro.erp.ui.secure.demobooker.InputBookingActivity;
import com.wadaro.erp.ui.secure.demobooker.LaporanHasilBookingActivity;
import com.wadaro.erp.ui.secure.demobooker.PenugasanSPActivity;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends SecureBaseUi implements HomeMenuGridViewAdapter.OnRecyclerViewClickListener{

    @Override
    protected int getContentViewId() {
        return R.layout.activity_home_page;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_home;
    }

    @Override
    protected void onMyCreate() {

        RecyclerView gridView = findViewById(R.id.rvGrid);
        RecyclerView listView = findViewById(R.id.rvList);

        listView.setHasFixedSize(true);
        gridView.setHasFixedSize(true);

        //set layout manager and adapter for "GridView"
        GridLayoutManager layoutManager = new GridLayoutManager(this, 4);
        gridView.setLayoutManager(layoutManager);
        HomeMenuGridViewAdapter gridViewAdapter = new HomeMenuGridViewAdapter(this, getAllItemObject());
        gridViewAdapter.setOnItemClickListener(this);
        gridView.setAdapter(gridViewAdapter);

        //set layout manager and adapter for "ListView"
        LinearLayoutManager horizontalManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true);
        listView.setLayoutManager(horizontalManager);
        HomeNewsListViewAdapter listViewAdapter = new HomeNewsListViewAdapter(this, getDummyHtml());
        listView.setAdapter(listViewAdapter);

//        GridView myGridview = (GridView) findViewById(R.id.gvTopMenu);
//        HomePageAdapter customAdapter = new HomePageAdapter(HomePageActivity.this, getAllItemObject());
//        myGridview.setAdapter(customAdapter);
//        myGridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//        });

//
//        List<ItemObject> allItems = getAllItemObject();
//        HomePageAdapter customAdapter = new HomePageAdapter(HomePageActivity.this, allItems);
//        gridview.setAdapter(customAdapter);
//        gridview.setNestedScrollingEnabled(false);
//
//        ListView listview = (ListView) findViewById(R.id.lvNews);
//        NewsListAdapter listAdapter = new NewsListAdapter(HomePageActivity.this, getDummyHtml());
//        listview.setAdapter(listAdapter);
//        listview.setNestedScrollingEnabled(false);

    }

    private List<ItemObject> getAllItemObject(){
        ItemObject itemObject = null;
        List<ItemObject> items = new ArrayList<>();
        items.add(new ItemObject("Data Areal Garapan", "ic_dataarealgarapan"));
//        items.add(new ItemObject("Input JP", "ic_input_jp"));
        items.add(new ItemObject("Input Booking", "ic_bottom_booking"));
        items.add(new ItemObject("Data Booking", "ic_bottom_data"));
        items.add(new ItemObject("Penugasan SP", "ic_bottom_penugasan"));
        items.add(new ItemObject("Rekap Hasil Booking", "ic_rekap"));
        items.add(new ItemObject("Profil", "ic_bottom_profile"));

        return items;
    }

    private List<String> getDummyHtml(){

        String about = "<html> <body> <h2> Jayalalithaa Jayaram </h2> (24 February 1948 – 5 December 2016)" +
                " was an Indian actress and politician who served five terms as the Chief Minister of Tamil Nadu," +
                " for over fourteen years between 1991 and 2016.</body> </html>";


        String about2 = "<html> <body> <h2> Jayalalithaa Jayaram </h2> (24 February 1948 – 5 December 2016)" +
                " was an Indian actress and politician who served five terms as the Chief Minister of Tamil Nadu," +
                " for over fourteen years between 1991 and 2016. </body> </html>";


        List<String> temp = new ArrayList<>();
        temp.add(about);
        temp.add(about2);
        temp.add(about2);
        temp.add(about2);

        return temp;
    }


    @Override
    public void onItemClick(Integer position) {
//        Toast.makeText(this, "klik aja", Toast.LENGTH_SHORT).show();
        if(position == 0) {
            startActivity(new Intent(this, DataArealGarapanActivity.class));
//        } else if(position == 1){
//            startActivity(new Intent(this, InputJPActivity.class));
        } else if(position == 1){
            startActivity(new Intent(this, InputBookingActivity.class));
        } else if(position == 2){
            startActivity(new Intent(this, DataBookingActivity.class));
        } else if(position == 3){
            startActivity(new Intent(this, PenugasanSPActivity.class));
        } else if(position == 4){
            startActivity(new Intent(this, LaporanHasilBookingActivity.class));
        } else if(position == 5){
            startActivity(new Intent(this, ProfilActivity.class));
        } else {
//            Toast.makeText(this, "klik"+position, Toast.LENGTH_SHORT).show();
        }
    }
}
