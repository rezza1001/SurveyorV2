package com.wadaro.erp.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wadaro.erp.R;

import java.util.List;

/**
 * Created by pho0890910 on 2/23/2019.
 */
public class HomeNewsListViewAdapter extends RecyclerView.Adapter<HomeNewsListViewAdapter.ViewHolder> {

    private Activity activity;
    private List<String> items;

    public HomeNewsListViewAdapter(Activity activity, List<String> items) {
        this.activity = activity;
        this.items = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View view = inflater.inflate(R.layout.item_text, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

//        viewHolder.webInListView.loadData(items.get(position).toString(), "text/html", "UTF-8");

        viewHolder.textView.setText(showHtml(items.get(position).toString()));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * View holder to display each RecylerView item
     */
    protected static class ViewHolder extends RecyclerView.ViewHolder {
        //        private ImageView imageView;
        private TextView textView;
//        WebView webInListView;

        public ViewHolder(View view) {
            super(view);
//            webInListView = (WebView) view.findViewById(R.id.wvContent);
            textView = (TextView) view.findViewById(R.id.textView);
        }

    }

    public static Spanned showHtml(String html) {
        Spanned result;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            result = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            result = Html.fromHtml(html);
        }
        return result;
    }

}
