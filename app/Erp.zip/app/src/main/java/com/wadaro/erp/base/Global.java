package com.wadaro.erp.base;

import android.content.Context;

import com.wadaro.erp.model.UserInformation;

/**
 * Created by pho0890910 on 2/20/2019.
 */
public class Global {

    public static UserInformation userInformation = null;

    public static void startAppIniData( Context p_context)
    {
        Shared.initialize(p_context);
    }

    public static void clearGlobalData(){
        userInformation = null;
    }

}
