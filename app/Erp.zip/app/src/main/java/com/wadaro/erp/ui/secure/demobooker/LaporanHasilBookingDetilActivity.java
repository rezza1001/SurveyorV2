package com.wadaro.erp.ui.secure.demobooker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.wadaro.erp.R;
import com.wadaro.erp.ui.secure.SecureBaseUi;

public class LaporanHasilBookingDetilActivity extends SecureBaseUi {

    @Override
    protected int getContentViewId() {
        return R.layout.activity_laporan_hasil_booking_detil;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return null;
    }

    @Override
    protected void onMyCreate() {

        showBackButton();
    }

}
