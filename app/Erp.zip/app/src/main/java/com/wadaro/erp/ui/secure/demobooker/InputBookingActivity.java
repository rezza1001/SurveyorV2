package com.wadaro.erp.ui.secure.demobooker;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.wadaro.erp.R;
import com.wadaro.erp.ui.secure.InputJPActivity;
import com.wadaro.erp.ui.secure.SecureBaseUi;

import java.util.ArrayList;
import java.util.Calendar;

public class InputBookingActivity extends SecureBaseUi implements View.OnClickListener{

    TextView tvOnline;
    ImageButton btnDatePicker, btnTimePicker;
    TextView txtDate, txtTime;
    Button btnCekNIK;

    private int mYear, mMonth, mDay, mHour, mMinute;

    @Override
    protected int getContentViewId() {
        return R.layout.activity_input_booking;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_booking;
    }

    @Override
    protected void onMyCreate() {

        tvOnline = findViewById(R.id.tvOnline);

        btnDatePicker=findViewById(R.id.btnCalendar);
        btnTimePicker=findViewById(R.id.btnJam);
        btnCekNIK=findViewById(R.id.btnCekNIK);
        txtDate=findViewById(R.id.tvDisplayTanggalDemo);
        txtTime=findViewById(R.id.tvDisplayJamDemo);

        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
        btnCekNIK.setOnClickListener(this);

        Switch switchOnline = findViewById(R.id.switchOnline);

//        default
        switchOnline.setChecked(true);
        tvOnline.setText("Online");

        switchOnline.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    tvOnline.setTextColor(getResources().getColor(R.color.colorAccent));
                    tvOnline.setText("Online");
                } else {
                    tvOnline.setTextColor(getResources().getColor(R.color.dialog_background));
                    tvOnline.setText("Offline");
                }
            }
        });


        ArrayList<String> temp = new ArrayList<>();
        temp.add("Pondok Aren / Perigi Baru");
        temp.add("Ciputat / Ciputat");

        Spinner spinner = (Spinner) findViewById(R.id.spAlamatArea);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        ArrayList<String> temp2 = new ArrayList<>();
        temp2.add("Demo 1");
        temp2.add("Demo 2");

        Spinner spinner2 = (Spinner) findViewById(R.id.spJadwalDemo);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp2);

        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        Button btnSimpan = findViewById(R.id.btnSimpan);
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InputBookingActivity.this, InputJPActivity.class));
            }
        });

    }

    @Override
    public void onClick(View v) {
        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        } else if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            txtTime.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        } else if (v == btnCekNIK) {
            startActivity(new Intent(this, CekNIKActivity.class));
        }
    }
}
