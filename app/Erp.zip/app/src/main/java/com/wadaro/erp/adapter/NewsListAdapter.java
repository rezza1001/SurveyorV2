package com.wadaro.erp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;

import com.wadaro.erp.R;

import java.util.List;

/**
 * Created by pho0890910 on 2/23/2019.
 */
public class NewsListAdapter extends BaseAdapter {

    private LayoutInflater layoutinflater;
    private List<String> listStorage;
    private Context context;

    public NewsListAdapter(Context context, List<String> customizedListView) {
        this.context = context;
        layoutinflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        listStorage = customizedListView;
    }

    @Override
    public int getCount() {
        return listStorage.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        NewsListAdapter.ViewHolder listViewHolder;
        if (convertView == null) {
            listViewHolder = new NewsListAdapter.ViewHolder();
            convertView = layoutinflater.inflate(R.layout.item_text, parent, false);

//            listViewHolder.webInListView = (WebView) convertView.findViewById(R.id.wvContent);

//            listViewHolder.textInListView = (TextView) convertView.findViewById(R.id.textView);
//            listViewHolder.imageInListView = (ImageView) convertView.findViewById(R.id.imageView);
            convertView.setTag(listViewHolder);
        } else {
            listViewHolder = (NewsListAdapter.ViewHolder) convertView.getTag();
        }

//        listViewHolder.textInListView.setText(listStorage.get(position).getContent());
//        int imageResourceId = this.context.getResources().getIdentifier(listStorage.get(position).getImageResource(), "drawable", this.context.getPackageName());
//        listViewHolder.imageInListView.setImageResource(imageResourceId);

        listViewHolder.webInListView.loadData(listStorage.get(0), "text/html", "UTF-8");

        return convertView;
    }

    static class ViewHolder {
        WebView webInListView;
    }

}
