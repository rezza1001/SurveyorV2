package com.wadaro.erp.ui.secure;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.wadaro.erp.R;
import com.wadaro.erp.module.log.MyLog;
import com.wadaro.erp.ui.BaseUi;
import com.wadaro.erp.ui.secure.demobooker.DataBookingActivity;
import com.wadaro.erp.ui.secure.demobooker.InputBookingActivity;
import com.wadaro.erp.ui.secure.demobooker.PenugasanSPActivity;

/**
 * Created by pho0890910 on 2/21/2019.
 */
public abstract class SecureBaseUi extends BaseUi implements BottomNavigationView.OnNavigationItemSelectedListener {

    BottomNavigationView navigationView;
    MenuItem menuItem;

    protected abstract int getContentViewId();
    protected abstract Integer getNavigationMenuItemIndex();
    protected abstract void onMyCreate();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(getContentViewId());

        configBottomNavigationView();

        onMyCreate();

    }

    protected void showBackButton(){
        LinearLayout llBack = findViewById(R.id.llBack);
        llBack.setVisibility(View.VISIBLE);

        ImageButton ibBack = findViewById(R.id.ibBack);
        ibBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    void configBottomNavigationView(){
        navigationView = findViewById(R.id.bottom_nav_bar);
        if(navigationView!=null) navigationView.setOnNavigationItemSelectedListener(this);

//        dummy
        if(navigationView!=null) navigationView.inflateMenu(R.menu.menu_demobooker);

//        MyLog.info("UserLevel : "+ Global.loginProfile.getUserLvl());
//
//        if(Global.loginProfile.getUserLvl() == 1){
//            // jukir
//            navigationView.inflateMenu(R.menu.main_menu);
//
//        } else if(Global.loginProfile.getUserLvl() == 2){
//            // supervisor
//            navigationView.inflateMenu(R.menu.main_menu_spv);
//
//        } else {
//             koord
//            navigationView.inflateMenu(R.menu.main_menu_spv);
//        }

        setCheckedBottomMenu();
    }

    void setCheckedBottomMenu(){
        if(getNavigationMenuItemIndex() != null){
            Menu menu = navigationView.getMenu();
            menuItem = menu.findItem(getNavigationMenuItemIndex());

            if(menuItem!=null) menuItem.setChecked(true);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        MyLog.info("Bottom Navigation Bar. onNavigationItemSelected clicked");

        switch (item.getItemId()) {
            case R.id.bottom_home:
                startActivity(new Intent(this, HomePageActivity.class));
                return true;
            case R.id.bottom_booking:
                startActivity(new Intent(this, InputBookingActivity.class));
                return true;
            case R.id.bottom_data:
                startActivity(new Intent(this, DataBookingActivity.class));
                return true;
            case R.id.bottom_penugasan:
                startActivity(new Intent(this, PenugasanSPActivity.class));
                return true;
            case R.id.bottom_profile:
                startActivity(new Intent(this, ProfilActivity.class));
                return true;

//            case R.id.bottom_jukir:
//                startActivity(new Intent(this, DashboardSupervisorActivity.class));
//                return true;
        }

        return false;
    }

    @Override
    protected void onStart() {
        super.onStart();

        if(navigationView!=null) setCheckedBottomMenu();
    }
}
