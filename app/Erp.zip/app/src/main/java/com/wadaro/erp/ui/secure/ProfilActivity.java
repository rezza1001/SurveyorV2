package com.wadaro.erp.ui.secure;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.wadaro.erp.R;
import com.wadaro.erp.adapter.HomeMenuGridViewAdapter;
import com.wadaro.erp.adapter.ProfilGridViewAdapter;
import com.wadaro.erp.model.ItemObject;

import java.util.ArrayList;
import java.util.List;

public class ProfilActivity extends SecureBaseUi
        implements ProfilGridViewAdapter.OnRecyclerViewClickListener {

    @Override
    protected int getContentViewId() {
        return R.layout.activity_profil;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_profile;
    }

    @Override
    protected void onMyCreate() {

        RecyclerView gridView = findViewById(R.id.rvGrid);
        gridView.setHasFixedSize(true);

        //set layout manager and adapter for "GridView"
        GridLayoutManager layoutManager = new GridLayoutManager(this, 4);
        gridView.setLayoutManager(layoutManager);
        ProfilGridViewAdapter gridViewAdapter = new ProfilGridViewAdapter(this, getAllItemObject());
        gridViewAdapter.setOnItemClickListener(this);
        gridView.setAdapter(gridViewAdapter);
    }

    private List<ItemObject> getAllItemObject(){
        ItemObject itemObject = null;
        List<ItemObject> items = new ArrayList<>();
        items.add(new ItemObject("Ganti Password", "ic_password"));
        items.add(new ItemObject("Ganti Foto", "ic_photo"));
        items.add(new ItemObject("Keluar", "ic_keluar"));

        return items;
    }

    @Override
    public void onItemClick(Integer position) {
//        if(position == 1){
//            Toast.makeText(this, "klik"+position, Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(this, "klik"+position, Toast.LENGTH_SHORT).show();
//        }
    }
}
