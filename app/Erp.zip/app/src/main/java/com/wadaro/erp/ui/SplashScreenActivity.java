package com.wadaro.erp.ui;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.wadaro.erp.R;
import com.wadaro.erp.base.Global;
import com.wadaro.erp.base.Shared;
import com.wadaro.erp.model.UserInformation;

public class SplashScreenActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {

                // init sharedPreference
                Global.startAppIniData(SplashScreenActivity.this);

                redirect();

                finish();
            }
        }, SPLASH_TIME_OUT);

    }

    private void redirect(){

        // todo. dummy
//        Shared.logoutUser();

        if(Shared.isLoggedIn()){

            UserInformation po = Shared.getUserInformation();
            if(po == null){

                Shared.clear();
                Global.clearGlobalData();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));

            } else {
                // level user
                // koordinator
//                if(po.getUserLevel() == 3){
//                    startActivity(new Intent(getApplicationContext(), DashboardSupervisorActivity.class));
//                    // supervisor
//                } else if(po.getUserLevel() == 2){
//                    startActivity(new Intent(getApplicationContext(), DashboardSupervisorActivity.class));
//                    // jukir
//                } else {
//                    startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
//                }
            }
        } else {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }
    }

}
