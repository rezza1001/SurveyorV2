package com.wadaro.erp.module.dialog;

public interface IMyDialog
{
	public void aDialogLeft(int p_intDialogId, Object p_obj);

	public void aDialogRight(int p_intDialogId, Object p_obj);

	public void aDialogMid(int p_intDialogId, Object p_obj);

}
