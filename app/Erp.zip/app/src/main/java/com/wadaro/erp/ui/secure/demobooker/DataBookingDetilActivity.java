package com.wadaro.erp.ui.secure.demobooker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.wadaro.erp.R;
import com.wadaro.erp.ui.secure.SecureBaseUi;

public class DataBookingDetilActivity extends SecureBaseUi {

    @Override
    protected int getContentViewId() {
        return R.layout.activity_data_booking_detil;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_data;
    }

    @Override
    protected void onMyCreate() {

        showBackButton();


    }


}
