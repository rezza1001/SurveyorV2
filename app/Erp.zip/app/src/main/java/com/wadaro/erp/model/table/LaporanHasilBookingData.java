package com.wadaro.erp.model.table;

/**
 * Created by pho0890910 on 2/26/2019.
 */
public class LaporanHasilBookingData {

    public int id;
    public String demo;
    public String jam;
    public String kordinator;
    public String sales;
    public String status;

}
