package com.wadaro.erp.ui.secure;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.wadaro.erp.R;

public class InputJPActivity extends SecureBaseUi {

    @Override
    protected int getContentViewId() {
        return R.layout.activity_input_jp;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return R.id.bottom_booking;
    }

    @Override
    protected void onMyCreate() {
        showBackButton();
    }

}
