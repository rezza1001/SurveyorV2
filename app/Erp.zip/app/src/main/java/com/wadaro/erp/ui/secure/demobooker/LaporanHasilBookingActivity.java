package com.wadaro.erp.ui.secure.demobooker;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.wadaro.erp.R;
import com.wadaro.erp.ui.secure.SecureBaseUi;
import com.wadaro.erp.ui.secure.demobooker.databooking.adapter.DataBookingPagerAdapter;
import com.wadaro.erp.ui.secure.demobooker.databooking.fragment.MapFragment;
import com.wadaro.erp.ui.secure.demobooker.databooking.fragment.TabelFragment;
import com.wadaro.erp.ui.secure.demobooker.laporanhasilbooking.fragment.LaporanTabelFragment;

import java.util.ArrayList;

public class LaporanHasilBookingActivity extends SecureBaseUi {

    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected int getContentViewId() {
        return R.layout.activity_laporan_hasil_booking;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return null;
    }

    @Override
    protected void onMyCreate() {

        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.pager);

        LaporanTabelFragment tabelFragment = new LaporanTabelFragment();
        MapFragment mapFragment = new MapFragment();

        DataBookingPagerAdapter adapter = new DataBookingPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(tabelFragment, getString(R.string.tabel_fragment));
        adapter.addFragment(mapFragment, getString(R.string.map_fragment));

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        ArrayList<String> tempTgl = new ArrayList<>();
        tempTgl.add("2019-03-01");
        tempTgl.add("2019-03-02");

        ArrayList<String> tempDemo = new ArrayList<>();
        tempDemo.add("Semua Demo");

        Spinner spinnerTgl = (Spinner) findViewById(R.id.spTanggal);
        Spinner spinnerDemo = (Spinner) findViewById(R.id.spDemo);

        ArrayAdapter<String> adapterSpinnerTgl =
                new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tempTgl);
        ArrayAdapter<String> adapterSpinnerDemo =
                new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tempDemo);

        adapterSpinnerTgl.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTgl.setAdapter(adapterSpinnerTgl);
        adapterSpinnerDemo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDemo.setAdapter(adapterSpinnerDemo);

    }

}
