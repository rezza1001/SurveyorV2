package com.wadaro.erp.model.table;

import java.util.Date;

/**
 * Created by pho0890910 on 2/26/2019.
 */
public class DemoData {

    public int id;
    public String demo;
    public String jam;
    public String kordinator;
    public String alamat;

}
