package com.wadaro.erp.ui.secure.demobooker;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.wadaro.erp.R;
import com.wadaro.erp.model.table.ArealPenugasanData;
import com.wadaro.erp.ui.secure.SecureBaseUi;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DataArealGarapanActivity extends SecureBaseUi {

    private TableLayout mTableLayout;
    ProgressDialog mProgressBar;


    @Override
    protected int getContentViewId() {
        return R.layout.activity_data_areal_garapan;
    }

    @Override
    protected Integer getNavigationMenuItemIndex() {
        return null;
    }

    @Override
    protected void onMyCreate() {

        mProgressBar = new ProgressDialog(this);

        ArrayList<String> temp = new ArrayList<>();
        temp.add("Januari");
        temp.add("Febuari");

        Spinner spinner = (Spinner) findViewById(R.id.spBulan);
// Create an ArrayAdapter using the string array and a default spinner layout
//        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
//                temp, android.R.layout.simple_spinner_item);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, temp);


// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        mTableLayout = (TableLayout) findViewById(R.id.tableDataArealPenugasan);

        mTableLayout.setStretchAllColumns(true);
        mTableLayout.setColumnShrinkable(1,true);
        mTableLayout.setColumnShrinkable(2,true);
        startLoadData();
    }

    public void startLoadData() {

        mProgressBar.setCancelable(false);
        mProgressBar.setMessage("Fetching Invoices..");
        mProgressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        mProgressBar.show();
        new LoadDataTask().execute(0);

    }

    public void loadData() {

        int leftRowMargin=0;
        int topRowMargin=0;
        int rightRowMargin=0;
        int bottomRowMargin = 0;
        int textSize = 0, smallTextSize =0, mediumTextSize = 0;

        textSize = (int) getResources().getDimension(R.dimen.font_size_verysmall);
        smallTextSize = (int) getResources().getDimension(R.dimen.font_size_small);
        mediumTextSize = (int) getResources().getDimension(R.dimen.font_size_medium);

        ArealPenugasanData[] data = getArealPenugasanData();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");

        int rows = data.length;
//        getSupportActionBar().setTitle("Invoices (" + String.valueOf(rows) + ")");
        TextView textSpacer = null;

        mTableLayout.removeAllViews();

        // -1 means heading row
        for(int i = -1; i < rows; i ++) {
            ArealPenugasanData row = null;
            if (i > -1)
                row = data[i];
            else {
                textSpacer = new TextView(this);
                textSpacer.setText("");

            }
            // data columns
            final TextView tv = new TextView(this);
            tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.MATCH_PARENT));

            tv.setPadding(5, 15, 0, 15);
            if (i == -1) {
                tv.setText("Tanggal");
                tv.setBackgroundColor(Color.parseColor("#f0f0f0"));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv.setBackgroundColor(Color.parseColor("#f8f8f8"));
                tv.setText(" "+dateFormat.format(row.tanggal));
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv.setGravity(Gravity.LEFT);
            }

            final TextView tv2 = new TextView(this);
            tv2.setPadding(5, 15, 0, 15);
            if (i == -1) {
                tv2.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv2.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv2.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv2.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv2.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv2.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv2.setText("Kecamatan");
                tv2.setBackgroundColor(Color.parseColor("#f7f7f7"));
            }else {
                tv2.setBackgroundColor(Color.parseColor("#ffffff"));
                tv2.setTextColor(Color.parseColor("#000000"));
                tv2.setText(" "+row.kecamatan);
            }

            final TextView tv3 = new TextView(this);
            tv3.setPadding(5, 15, 0, 15);

            if (i == -1) {
                tv3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv3.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
                tv3.setGravity(Gravity.CENTER_HORIZONTAL);
            } else {
                tv3.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT));
                tv3.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
                tv3.setGravity(Gravity.LEFT);
            }

            if (i == -1) {
                tv3.setText("Kelurahan");
                tv3.setBackgroundColor(Color.parseColor("#f0f0f0"));
            } else {
                tv3.setBackgroundColor(Color.parseColor("#f8f8f8"));
                tv3.setTextColor(Color.parseColor("#000000"));
                tv3.setText(" "+row.kelurahan);
            }

//            final TextView tv4 = new TextView(this);
//            if (i == -1) {
//                tv4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
//                        TableRow.LayoutParams.WRAP_CONTENT));
//                tv4.setGravity(Gravity.CENTER_HORIZONTAL);
//            } else {
//                tv4.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
//                        TableRow.LayoutParams.WRAP_CONTENT));
//                tv4.setGravity(Gravity.LEFT);
//            }
//
//            if (i == -1) {
//                tv4.setText("Kelurahan");
//                tv4.setBackgroundColor(Color.parseColor("#f7f7f7"));
//                tv4.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallTextSize);
//            } else {
//                tv4.setBackgroundColor(Color.parseColor("#ffffff"));
//                tv4.setTextColor(Color.parseColor("#000000"));
//                tv4.setText(row.kelurahan);
//                tv4.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
//            }
//
//            tv4.setPadding(5, 15, 0, 15);


            // add table row
            final TableRow tr = new TableRow(this);
            tr.setId(i + 1);
            TableLayout.LayoutParams trParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT);
            trParams.setMargins(leftRowMargin, topRowMargin, rightRowMargin, bottomRowMargin);
            tr.setPadding(0,0,0,0);
            tr.setLayoutParams(trParams);

            tr.addView(tv);
            tr.addView(tv2);
            tr.addView(tv3);
//            tr.addView(tv4);

            mTableLayout.addView(tr, trParams);

            if (i > -1) {

                // add separator row
                final TableRow trSep = new TableRow(this);
                TableLayout.LayoutParams trParamsSep = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                        TableLayout.LayoutParams.WRAP_CONTENT);
                trParamsSep.setMargins(leftRowMargin, topRowMargin, rightRowMargin, bottomRowMargin);

                trSep.setLayoutParams(trParamsSep);
                TextView tvSep = new TextView(this);
                TableRow.LayoutParams tvSepLay = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT);
                tvSepLay.span = 3;
                tvSep.setLayoutParams(tvSepLay);
                tvSep.setBackgroundColor(Color.parseColor("#d9d9d9"));
                tvSep.setHeight(1);

                trSep.addView(tvSep);
                mTableLayout.addView(trSep, trParamsSep);
            }

        }
    }

    //
    // The params are dummy and not used
    //
    class LoadDataTask extends AsyncTask<Integer, Integer, String> {
        @Override
        protected String doInBackground(Integer... params) {

            try {
                Thread.sleep(500);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return "Task Completed.";
        }
        @Override
        protected void onPostExecute(String result) {
            mProgressBar.hide();
            loadData();
        }
        @Override
        protected void onPreExecute() {
        }
        @Override
        protected void onProgressUpdate(Integer... values) {

        }
    }

    // todo. dummy now
    public ArealPenugasanData[] getArealPenugasanData() {
        ArealPenugasanData[] data = new ArealPenugasanData[50];
        for(int i = 0; i < 50; i ++) {
            ArealPenugasanData row = new ArealPenugasanData();
            row.id = (i+1);
            row.tanggal = new Date();
            row.kecamatan =  "Jurang Mangu";
            row.kelurahan = "Jurang Mangu Barat";

            data[i] = row;
        }
        return data;
    }
}
